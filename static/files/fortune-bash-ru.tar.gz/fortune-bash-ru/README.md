bash.im parser
==============

Generates *fortune-mod* quotes file from the popular website bash.im

Requires: fortune-mod, python-beautifulsoup

### Parser ###

First you will need to fetch and parse pages, containing quotes. This is done with the *parse.py* script:

    ./parse.py [start_page] [end_page]

*Example*

    ./parse.py 1 10

The quotes are appended to the fortune-compatible text file named "bash". If this file doesn't exist it will be created.

### Makefile ###

Makes fortune pointer file:
    
    make all

Installs quotes to the fortune catalog:

    make install

Cleans:

    make clean

