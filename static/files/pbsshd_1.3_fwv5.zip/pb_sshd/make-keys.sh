#!/bin/sh
# Modify this if you want to use a passphrase
PASSPHRASE=""

usr/bin/ssh-keygen -b 1024 -t rsa -f ./id_rsa -N "$PASSPHRASE"
cat ./id_rsa.pub >> etc/ssh/authorized_keys2
echo "Move id_rsa and id_rsa.pub to your desktop machine."
