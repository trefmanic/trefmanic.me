#!/bin/sh
# Create host keys if needed.
if [ ! -r etc/ssh/ssh_host_key ]; then
  usr/bin/ssh-keygen -t rsa1 -f etc/ssh/ssh_host_key -N '' 
fi
if [ ! -f etc/ssh/ssh_host_dsa_key ]; then
  usr/bin/ssh-keygen -t dsa -f etc/ssh/ssh_host_dsa_key -N ''
fi
if [ ! -f etc/ssh/ssh_host_rsa_key ]; then
  usr/bin/ssh-keygen -t rsa -f etc/ssh/ssh_host_rsa_key -N ''
fi
if [ ! -f etc/ssh/ssh_host_ecdsa_key ]; then
  usr/bin/ssh-keygen -t ecdsa -f etc/ssh/ssh_host_ecdsa_key -N ''
fi

