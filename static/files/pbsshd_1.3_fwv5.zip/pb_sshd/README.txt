This package contains the binary programs and shell scripts required
for running a non-privileged sshd daemon on PocketBook Pro readers.
Non-privileged means that you don't need to root the device to install
and run these programs; they run under the default "reader" user
account.  It also means that you do _not_ get root privileges when
running these programs.  You can only do the things the "reader"
account is normally permitted to do.

When the daemon is running with WiFi enabled on the device, you
can: 1) "scp" files to and from the device from your computer,
2) "sftp" (secure FTP) from the computer to the device, and
3) "ssh" to the device for shell access.  "scp" and "sftp" seem
to work flawlessly for me, but "ssh" has a problem because the
device is not set up to allow the "reader" account to create new
pseudo-ttys.  The shell still "works", but there is no prompt,
and no command-line editting (i.e. you can't fix typos or pull up
old commands with the arrow keys).  See below for more on this.
Most Linux systems come with the openssh programs pre-installed.
On Windows, you can use the free Putty ssh software instead.

Because "sshd" runs under a non-privileged account, it does not
have access to any passwords.  Because of this, you must use keys
for authorization rather than passwords.  This is covered in the
"Installation" section below.

If you want to build your own version of "sshd", see the "Building
SSHD Programs" section at the end of this file.

(Note to Windows users: the word "directory" in Unix-speak is
 equivalent to "folder" in Windows-speak)

Good luck!
Rob Komar



Installation:
------------

First, mount the ereader filesystems via USB and unzip this package
within the "applications" directory.  This will copy the "sshd_start.app"
and "sshd_stop.app" scripts there and make them available within the
ereader's "Applications" screen.  It also copies the required sshd
programs and scripts to the applications/pb_sshd directory.

The pb_sshd/etc/ssh/sshd_config file contains setup parameters such as
the port number that the daemon will listen to, and the locations of some
files required by the daemon.  The default configuration sets the port to
1124, and looks for keys in /mnt/ext1/applications/pb_sshd/etc/ssh/.
If these programs are installed elsewhere, or a different port number
is required, then edit pb_sshd/etc/ssh/sshd_config to reflect the
correct settings.  Since "sshd" runs under a non-privileged account,
the port number must be larger than 1024.  The defaults should work
fine, though.

Before you can use this software, you need to provide sshd with a
public authorization key for logging in.  If you already have such
a key on your computer, then you just need to copy it as is to
pb_sshd/etc/ssh/authorized_keys2 (as specified in the sshd_config
file).  Such keys are usually called something like "id_rsa.pub" and
are found in .ssh/ within the home directory on the computer.  For
example, you could use the following command under Linux if the
filesystem was mounted under /mnt:

> cat ~/.ssh/id_rsa.pub >> /mnt/applications/pb_sshd/etc/ssh/authorized_keys2

If you don't have a key yet, you could generate one on the computer using
"ssh-keygen" on Unix systems, or with something like puttygen.exe on
Windows systems.  On a Unix system, use a command like:

> ssh-keygen -b 1024 -t rsa

and it will generate private and public keys in ~/.ssh.  You can
use a passphrase if you like (it only needs to be typed in on the
computer, and not on the ereader).  Then copy the contents of the
public key to the authorized_keys2 file as above.

Otherwise, if you have "poterm" installed on the ereader, I have
provided a script file called "pb_sshd/make-keys.sh" to generate
keys without a passphrase.  The script automatically adds the
public key contents to the authorized_keys2 file.  Afterwards,
you need to move the "id_rsa" and "id_rsa.pub" files via USB to
your .ssh directory on your computer.

If you don't have "poterm", connect the reader up via USB and create
a file called "create-keys" in the "pb_sshd" directory.  It doesn't
matter what it contains.  The next time "sshd_start.app" is run, it
will automatically run the "pb_sshd/make-keys.sh" script (and then
delete the "create-keys" file).  Then you can move the "id_rsa" and
"id_rsa.pub" files from "pb_sshd" to your computer.  Thanks to
Axel (@apos) for this idea.



Using the software:
------------------

First, run "sshd_start" to enable WiFi if necessary and to start
the "sshd" daemon in the background.  Run "sshd_stop" to stop the
daemon and to turn off WiFi if it was started by "sshd_start".

If you want a dialog to pop up displaying the IP address and port
at which sshd is listening when the program is started, then
uncomment the line in sshd_start.app that begins with "#SH_IVTOOL=..."
(i.e. delete the '#' character at the beginning of the line).
You should also download and install the sh_ivtool.app file
at the location given in the line that was uncommented.  The
application is available at http://www3.telus.net/rkomar/sh_ivtool/.
Comment out the line again if you want the pop up to stop appearing.


On the computer, you need to provide the port number and IP address
to whatever client you use.  By default, the port number is 1124.
You will also have to specify the private authorization key file
if it is not in the default location, and the login account name.
N.B.  Within recent firmware versions, the account that the session
logs in as has changed from "reader" to "sreader".  So, you should
log in as "reader" with older firmwares, and "sreader" with newer
(e.g. 2.1.3).  I'm not sure at which firmware version the change
took place, so try both if you're not sure.

Here are some examples for running the programs on a Unix system if
the ereader has an IP address of 192.168.1.100:

to copy a file to the ereader:
old-fw> scp -P 1124 some-book.epub reader@192.168.1.100:/mnt/ext2/
new-fw> scp -P 1124 some-book.epub sreader@192.168.1.100:/mnt/ext2/

to copy a file from the ereader:
old-fw> scp -P 1124 reader@192.168.1.100:/mnt/ext2/some-book.epub .
new-fw> scp -P 1124 sreader@192.168.1.100:/mnt/ext2/some-book.epub .

to log in via sftp:
old-fw> sftp -P 1124 reader@192.168.1.100
new-fw> sftp -P 1124 sreader@192.168.1.100

to log in via a shell:
old-fw> ssh -p 1124 reader@192.168.1.100
new-fw> ssh -p 1124 sreader@192.168.1.100

In all of the above cases, the "-i" option can be used to specify
the private id_rsa key if it isn't in the default location.

(Unfortunately, I don't have much experience with Windows systems,
so I can't provide examples.  If anyone wants to provide instructions,
I can include them here, as well).



SSH Problems with Pseudo-ttys:
-----------------------------

As mentioned above, the ssh shell is very rudimentary on the ereader.
This is because the system has not been set up to allow non-privileged
users to create pseudo-ttys.  You can fix this if you can root your
ereader by making the following changes:

1) Remount the root partition as read-write, and then edit /etc/fstab and
   change the line for /dev/pts:

devpts	/dev/pts	devpts	rw,noexec,nosuid,gid=5,mode=620   0   0

2) Change the permissions on /usr/dev/ptmx, and then reboot the ereader
   (the /dev/ files are copied from /usr/dev/ when booting):

> chmod 666 /usr/dev/ptmx

I don't believe that either of these changes are a security risk
(they are the default on my desktop Linux machine), so it would be
good if someone who speaks Ukrainian or Russion could convince the
PocketBook team to make these changes to the official firmware.  It
would actually reduce the need for users to root their readers if
ssh shell access worked properly.



Building SSHD Programs:
-------------

The sshd programs found here were built from the openssh-5.9p1
source package without code modifications.  The source code is
available under the BSD license.  The following configuration
options were used to build the programs:

--disable-etc-default-login --without-shadow --with-pid-dir=/tmp \
--without-rpath --with-privsep-user=reader \
--with-privsep-path=/mnt/ext1/applications/pb_sshd/empty --without-pam \
--with-default-path=/bin:/usr/bin:/sbin:/usr/sbin:/mnt/ext1/system/bin:\
/mnt/ext1/applications/pb_sshd/usr/bin:/mnt/ext1/applications/pb_sshd/usr/sbin 

If you want to install these programs somewhere other than
/mnt/ext1/applications, then you should probably rebuild them
and modify the "--with-default-path" option to "configure".
"sshd" uses "ssh" when handling remote "scp" operations, so
it is important that "ssh" is available within the default path.

